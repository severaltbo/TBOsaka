﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Forms_Multi_Page
{
    public partial class MainPage : ContentPage
    {
        public String labelText { get; set; }
        public MainPage()
        {
            InitializeComponent();

            this.labelText = "Update Text";

            this.BindingContext = this;


        }
        private void Button_Clicked(Object sender, EventArgs e)
        {
            Navigation.PushAsync(new SubPage());

        }
    }
}
