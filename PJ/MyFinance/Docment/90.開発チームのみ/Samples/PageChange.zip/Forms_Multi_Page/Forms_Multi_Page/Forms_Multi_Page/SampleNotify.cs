﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Forms_Multi_Page
{
    class SampleNotify : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string _labelText;

        public string labelText
        {
            get { return _labelText; }
            set
            {
                if(this._labelText != value)
                {
                    this.PropertyChanged(this, new PropertyChangedEventArgs("labelText"));
                }
                _labelText = value;
            }
        }
    }
}
   