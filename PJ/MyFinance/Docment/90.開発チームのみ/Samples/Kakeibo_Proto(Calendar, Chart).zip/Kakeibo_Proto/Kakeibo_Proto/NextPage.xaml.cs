﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Kakeibo_Proto
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class NextPage : ContentPage
    {
        public NextPage()
        {
            InitializeComponent();
        }

        public NextPage(List<DateTime> dt)
        {
            InitializeComponent();
            CalendarDay.Text = dt[0].ToString("yyyy年MM月dd日");
        }
    }
}