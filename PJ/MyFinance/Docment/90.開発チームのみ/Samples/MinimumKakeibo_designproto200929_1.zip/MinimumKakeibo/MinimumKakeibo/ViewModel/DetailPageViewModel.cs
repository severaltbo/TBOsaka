﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace MinimumKakeibo.ViewModel
{
    public class DetailPageViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
