﻿using MinimumKakeibo.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using XamlSamples;

namespace MinimumKakeibo.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {

            //BindingContext = new MainPageViewModel();
            //var transbutton = new Button
            //{
            //    Text = "GOGOGO",
            //    TextColor = Color.White,
            //    BackgroundColor = Color.Green,
            //    Margin = new Thickness(10)
            //};
            //transbutton.SetBinding(Button.CommandProperty, "SaveNoteCommand");

            InitializeComponent();
        }

        private async void Input_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new InputPage());
        }

        private async void Detail_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new DetailPage());
        }

        private async void Search_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new SearchPage());
        }

        private async void OverView_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new OverviewPage());
        }

        private void SaveNoteCommand(object sender, EventArgs e)
        {

        }
    }
}