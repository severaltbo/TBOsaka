﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
namespace MinimumKakeibo.ViewModel
{
    public class SearchPageViewModel : ViewModelBase
    {
        
    }
}
