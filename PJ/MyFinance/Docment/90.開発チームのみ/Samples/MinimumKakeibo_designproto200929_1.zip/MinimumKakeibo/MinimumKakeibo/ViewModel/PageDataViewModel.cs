﻿using MinimumKakeibo.View;
using System;
using System.Collections.Generic;

namespace XamlSamples
{
    public class PageDataViewModel
    {
        public PageDataViewModel(Type type, string title, string description)
        {
            Type = type;
            Title = title;
            Description = description;
        }

        public Type Type { private set; get; }

        public string Title { private set; get; }

        public string Description { private set; get; }

        static PageDataViewModel()
        {
            All = new List<PageDataViewModel>
            {                
                new PageDataViewModel(typeof(DetailPage), "Detail Page Title",
                                      "Detail Page Description"),

                new PageDataViewModel(typeof(InputPage), "Input Page Title",
                                      "Input Page Description"),

                new PageDataViewModel(typeof(ListPage), "List Page Title",
                                      "List Page Description"),

                new PageDataViewModel(typeof(MainPage), "Main Page Title",
                                      "Main Page Description"),

                new PageDataViewModel(typeof(OverviewPage), "Overview Page Title",
                                      "Overview Page Description"),

                new PageDataViewModel(typeof(SearchPage), "Search Page Title",
                                      "Search Page Description"),
            };
        }

        public static IList<PageDataViewModel> All { private set; get; } 
    }
}
