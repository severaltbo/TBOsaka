﻿
using MinimumKakeibo.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace MinimumKakeibo.ViewModel
{
    public class MainPageViewModel : ViewModelBase
    {
        public MainPageViewModel()
        {
            SaveNoteCommand = new Command(() =>
            {
                var note = "9";
            });
        }

        public Command SaveNoteCommand { get; }
    }
}
