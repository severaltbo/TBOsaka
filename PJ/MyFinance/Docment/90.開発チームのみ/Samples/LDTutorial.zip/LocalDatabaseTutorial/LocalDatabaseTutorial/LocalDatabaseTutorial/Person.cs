﻿using SQLite;

namespace LocalDatabaseTutorial
{
    public class Person
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string Goods { get; set; }
        public int Money { get; set; }

        
    }
}