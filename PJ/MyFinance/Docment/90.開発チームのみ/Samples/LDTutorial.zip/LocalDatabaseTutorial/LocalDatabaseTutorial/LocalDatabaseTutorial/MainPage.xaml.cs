﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace LocalDatabaseTutorial
{
    public partial class MainPage : ContentPage
    {
        protected override async void OnAppearing()
        {
            base.OnAppearing();
            listView.ItemsSource = await App.Database.GetPeopleAsync();
        }

        async void OnButtonClicked(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(GoodsEntry.Text) && !string.IsNullOrWhiteSpace(MoneyEntry.Text))
            {
                await App.Database.SavePersonAsync(new Person
                {
                    Goods = GoodsEntry.Text,
                    Money = int.Parse(MoneyEntry.Text)
                

            }) ;

                GoodsEntry.Text = MoneyEntry.Text = string.Empty;
                listView.ItemsSource = await App.Database.GetPeopleAsync();
            }
        }
        public MainPage()
        {
            InitializeComponent();

            
        }
    }
}
